True Type Font: CHESS-7

EULA
The font Chess-7 is freeware for home using.

DESCRIPTION
This font created specially for game Chess-7 (donwload shareware version: http://www.styleseven.com/chess-7/chess-7.exe).
In this game you can export position as text in file or clipboard.
You can select preset for export (single line, single line with coordinates, double line, double line with coordinates) or customize you own key map (for example, you can set round corners or use any (!) another font).

Files in chess-7_tt_font.zip:
         README.TXT     This file.
         CHESS-7.TTF    CHESS-7 font - version 1.1
         CHESS-7.RTF    Sample and key map.

We will welcome any useful suggestions and comments; please send them to chess-7@styleseven.com

AUTHOR
Sizenko Alexander
Style-7
http://www.StyleSeven.com

Created: 7 July     2007
Updated: 3 November 2007
